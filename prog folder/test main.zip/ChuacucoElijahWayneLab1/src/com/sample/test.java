package com.sample;

public class test {
 

	public static void main(String[] args) {
		Car Civic = new Car(2019,"1.5L VTEC Turbo Engine, 173 PS‎", "NIO163" , 1.2, 170);
		System.out.println("Year Model : " + Civic.getModel());
		System.out.println("Engine Type : " + Civic.getEngine());
		System.out.println("Plate number : " +Civic.getPlatenumber());
		System.out.println("Price : " +Civic.getPrice() + "Million php");
		System.out.println("Topspeed : " + Civic.getTopspeed() +"mph (EST)");
				
    
	
     
	}
	

}