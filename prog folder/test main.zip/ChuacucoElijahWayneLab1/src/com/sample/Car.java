package com.sample;

public class  Car {

	private int model;
	private String engine;
	private String platenumber;
	private double price;
	private int topspeed;
	
	
	
	public Car(int model, String engine, String platenumber, double price,  int topspeed) {
		this.model = model;
		this.engine = engine;
		this.platenumber = platenumber;
		this.price = price;
		this.topspeed = topspeed;
		System.out.println("Car HONDA CIVIC...");
	}
	
	public int getModel() {
		return this.model;
	}
	
	public String getEngine() {
		return this.engine;
	}
	
	public String getPlatenumber() {
		return this.platenumber;
	}
	
	public double getPrice() {
		return this.price;
	}
	
	public int getTopspeed() {
		return this.topspeed;
	}

	
	

}
